<div class="col-md-12 footer-logo">

    <a href="#"><h4 class="white"><?php echo bloginfo('name') ?></h4></a>

</div>

<div class="footer-info col-md-12">

    <?php echo st_remove_wpautop(st_get_option('footer-text'),true) ?>

</div>