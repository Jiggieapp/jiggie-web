<?php
$sidebar=st_get_option('blog_sidebar_id');

dynamic_sidebar($sidebar);
?>